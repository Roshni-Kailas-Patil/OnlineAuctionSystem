import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AuctionDAO {
    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/auctiondb"; // Database URL
        String username = "root"; // Database username
        String password = "password"; // Database password
        return DriverManager.getConnection(url, username, password);
    }

    public AuctionItem getAuctionItemById(int itemId) throws SQLException {
        String sql = "SELECT * FROM auction_items WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, itemId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new AuctionItem(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("description"),
                        resultSet.getDouble("starting_price"),
                        resultSet.getDouble("current_bid")
                );
            }
        }
        return null;
    }
}

